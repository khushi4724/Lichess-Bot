=======
History
=======

0.3.1 (2020-02-24)
------------------

* Fix a small spelling mistake

0.3.0 (2020-02-24)
------------------

* Add ``ndjson.writer``
* Add ``ndjson.reader``

0.2.0 (2019-08-01)
------------------

* Add 3.7 support
* Remove 3.4 support

0.1.0 (2018-05-17)
------------------

* First release on PyPI.
