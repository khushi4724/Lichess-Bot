from abc import ABC


class AbstractClient(ABC):
    """An abstract class for a Client"""
    pass
