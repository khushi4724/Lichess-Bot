from abc import ABC


class AbstractChessBot(ABC):
    """An abstract class for Chess Bot API Endpoint"""
    pass
